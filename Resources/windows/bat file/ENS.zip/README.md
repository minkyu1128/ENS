# 전자고지시스템(ENS) 가이드


### 서버 기동/종료 방법
* 서버 기동
	* `startup-background.vbs` 파일 실행
	* `logprint.bat` 파일 실행하여 기동 중인 로그 확인
	
* 서버 종료
	* `shutdown.bat` 파일 실행


### 파일 정보
|File|Description|
|---|---|
|startup.bat|`webapp` 디렉토리에 있는 ENS war 파일을 실행하여 `서버를 기동` 한다.|
|shutdown.bat|`서버를 종료` 한다.|
|startup-background.vbs|`startup.bat` 파일을 `백그라운드에서 실행` 한다.|
|logprint.bat|ENS Application `로그를 실시간으로 확인` 한다.|
|service-regist.bat|윈도우 `서비스에 등록` 한다.|
|service-delete.bat|등록된 `서비스를 삭제` 한다.|


### 디렉토리 설명
|Directory|Description|
|---|---|
|logs|Application Log 파일이 저장되는 디렉토리.<p/>일 단위로 파일이 관리되며, 일정 파일사이즈를 초과할 경우 순번이 증가한 파일명이 생성된다.|
|webapp|실행할 War 파일이 위치한 디렉토리|
